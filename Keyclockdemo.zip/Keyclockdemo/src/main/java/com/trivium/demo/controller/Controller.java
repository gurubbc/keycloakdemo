package com.trivium.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

	@GetMapping("/users")
	public String helloUser()
	{
		
		return "Welcome Users";
	}
	
	@GetMapping("/admin")
	public String helloAdmin()
	{
		
		return "Welcome Admin";
	}
	
}
