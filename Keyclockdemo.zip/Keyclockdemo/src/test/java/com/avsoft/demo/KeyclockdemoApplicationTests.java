package com.avsoft.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyclockdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
